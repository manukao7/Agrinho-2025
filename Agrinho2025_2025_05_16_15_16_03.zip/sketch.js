function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let farmer;

let items = [];

let score = 0;

let gameOver = false;

function setup() {

  createCanvas(600, 400);

  farmer = new Farmer();

  textFont('Arial');

}

function draw() {

  background(100, 200, 100);

  if (!gameOver) {

    farmer.show();

    farmer.move();

    if (frameCount % 60 === 0) {

      items.push(new FallingItem());

    }

    for (let i = items.length - 1; i >= 0; i--) {

      items[i].update();

      items[i].show();

      if (items[i].hits(farmer)) {

        if (items[i].good) {

          score += 10;

        } else {

          score -= 5;

        }

        items.splice(i, 1);

      } else if (items[i].offScreen()) {

        items.splice(i, 1);

      }

    }

    fill(0);

    textSize(20);

    text("Pontos: " + score, 10, 30);

    if (score < 0) {

      gameOver = true;

    }

  } else {

    textSize(32);

    fill(255, 0, 0);

    textAlign(CENTER);

    text("Fim de jogo! Pontos: " + score, width / 2, height / 2);

    textSize(20);

    text("Pressione R para reiniciar", width / 2, height / 2 + 40);

  }

}

function keyPressed() {

  if (gameOver && key === 'r') {

    score = 0;

    gameOver = false;

    items = [];

  }

}

class Farmer {

  constructor() {

    this.x = width / 2;

    this.size = 60;

  }

  show() {

    fill(150, 75, 0);

    rect(this.x, height - this.size, this.size, this.size);

    fill(255);

    textSize(16);

    textAlign(CENTER);

    text("👨‍🌾", this.x + this.size / 2, height - this.size / 2 + 8);

  }

  move() {

    if (keyIsDown(LEFT_ARROW)) {

      this.x -= 5;

    }

    if (keyIsDown(RIGHT_ARROW)) {

      this.x += 5;

    }

    this.x = constrain(this.x, 0, width - this.size);

  }

}

class FallingItem {

  constructor() {

    this.x = random(width);

    this.y = 0;

    this.size = 40;

    this.speed = 4;

    this.good = random() < 0.6;

    this.symbol = this.good ? random(["🍎", "🥕", "🌽"]) : random(["🧪", "🗑️", "💣"]);

  }

  update() {

    this.y += this.speed;

  }

  show() {

    textSize(32);

    textAlign(CENTER);

    text(this.symbol, this.x + this.size / 2, this.y + this.size / 2);

  }

  hits(farmer) {

    return this.y + this.size > height - farmer.size &&

           this.x + this.size > farmer.x &&

           this.x < farmer.x + farmer.size;

  }

  offScreen() {

    return this.y > height;

  }

}

